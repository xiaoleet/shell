#!/bin/bash
#
# Func: Get Porcess Status In process.cfg

# Define Variables
HOME_DIR="/root/lesson/9.1"
CONFIG_FILE="process.cfg"
this_pid=$$


function get_all_group
{
	G_LIST=`sed -n '/\[GROUP_LIST\]/,/\[.*\]/p' $HOME_DIR/$CONFIG_FILE | egrep -v "(^$|\[.*\])"`
	echo "$G_LIST"
}

function get_all_process
{
	for g in `get_all_group`
	do
		P_LIST=`sed -n "/\[$g\]/,/\[.*\]/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^$|\[.*\])"`
		echo "$P_LIST"
	done
}

function is_process_in_config
{
	if [ $# -ne 1 ];then
		return 1
	else
		for p in `get_all_process`;do
			if [ $1 == $p ];then
				return
			fi
		done
	fi
	echo "Porcess $1 is not in process.cfg"
	return 1

}

function get_pid_by_process_name
{
	if [ $# -ne 1 ];then
		return 1
	else
		is_process_in_config $1
		if [ $? -eq 0 ];then
			pro_pid=`ps aux | grep $1 | grep -v grep  | grep -v $0 | awk '$2 != '$this_pid'{print $2}' `
			echo $pro_pid
		else
			echo "Process $1 is not in process.cfg"
			return 1
		fi
	fi
}

function get_process_info_by_pid
{
	if [ $# -ne 1 ];then
		return 1
	else
		pro_cpu=`ps aux | awk -v p=$1 '$2==p{print}' | awk '{print $3}'`
                pro_mem=`ps aux | awk -v p=$1 '$2==p{print}' | awk '{print $4}'`
                sta_time=`ps -p $1 -o lstart | grep -v STARTED`
		if [ `ps -ef | awk -v p=$1 '$2==p{print }' | wc -l` -eq 1 ];then
                	pro_status="RUNNING"
               	else
                	pro_status="STOPPED"
                fi
	fi
}

function get_processname_by_group
{
	if [ $# -eq 0 ];then
		return 1
	else
		echo `get_all_group` | grep $1 &> /dev/null
		if [ $? -ne 0 ];then
			echo "Group $1 is not in process.cfg"
			return 1
		else
			group_list=`sed -n "/\[$1\]/,/\[.*\]/p" $HOME_DIR/$CONFIG_FILE |  egrep -v  "(\[.*\]|^$|^#)"`
			echo $group_list
		fi
	fi
}

function get_group_by_processname
{
	for gn in `get_all_group`;do
		for pn in `get_processname_by_group $gn`;do
			if [ "$pn" == "$1" ];then
				echo "$gn"
			fi
		done
	done
}

function print_format
{
	ps -ef | grep $1 | grep -v grep | grep -v $this_pid &> /dev/null
        if [ $? -eq 0 ];then
        	for id in `get_pid_by_process_name $1`;do
        		get_process_info_by_pid $id
                        awk -v p_name=$1 -v p_group=$2 -v p_status=$pro_status -v p_pid=$id -v p_cpu=$pro_cpu -v p_mem=$pro_mem -v p_starttime="$sta_time" 'BEGIN{printf "%-20s%-20s%-12s%-12s%-12s%-12s%-18s\n",p_name,p_group,p_status,p_pid,p_cpu,p_mem,p_starttime}'
                done
        else
		awk -v p_name=$1 -v p_group=$2 'BEGIN{printf "%-20s%-20s%-12s%-12s%-12s%-12s%-18s\n",p_name,p_group,"STOPPED","NULL","NULL","NULL","NULL"}'
        fi
}

awk 'BEGIN{printf "%-20s%-20s%-12s%-12s%-12s%-12s%-18s\n", "PROCESS_NAME--------","GROUP--------------","STATUS------","PID--------","CPU---------","MEMORY------","START_TIME----------"}'

if [ $# -gt 0 ];then
	if [ "$1" == "-g" ];then
		shift
		g_list=$@
		for gn in $g_list;do	
			for pn in `get_processname_by_group $gn`;do
				is_process_in_config $pn && print_format $pn $gn
			done
		done
	else
		for pn in "$@";do
			gn=`get_group_by_processname $pn`
			is_process_in_config $pn && print_format $pn $gn
		done
	fi 
else
	for pn in `get_all_process`;do
		gn=`get_group_by_processname $pn`
		is_process_in_config $pn && print_format $pn $gn
	done
fi


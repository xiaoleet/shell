#!/bin/bash
#

this_pid=$$

echo $(pgrep -f $1 | grep -v pgrep | grep -v grep | grep -v $this_pid)

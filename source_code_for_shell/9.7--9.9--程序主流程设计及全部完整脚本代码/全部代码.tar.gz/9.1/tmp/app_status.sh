#!/bin/bash
#
# Func: Get Process Status Info In process.cfg

# Define Variables
HOME_DIR=/root/lesson/9.1/			# home directory
CONFIG_FILE=process.cfg				# config file name
G_LIST=""					# all groups in process.cfg
this_pid=$$

function clear_variables 
{
	process_name=""
	process_status="STOPPED"
	process_id="NULL"
	process_cpu="NULL"
	process_mem="NULL"
	process_group="NULL"
	start_time="2099-12-31 23:21:32"
}
# get all groups in process.cfg
function get_all_group 
{
	if [ ! -e $HOME_DIR/$CONFIG_FILE ];then
		echo "$CONFIG_FILE is not exist..please check.." 
		return 1
	else
		G_LIST=`sed -n "/^\[GROUP_LIST\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)"`
		if [ "$G_LIST" == "" ];then
			echo "no group in $CONFIG_FILE"
			return 1
		fi
	fi
}

# Get all process in process.cfg
function get_all_process
{
        all_pro=        # init variables
	get_all_group
        for g in $G_LIST;do
                all_pro="${all_pro} `sed -n "/^\[$g\]$/,/^\[.*\]$/p" process.cfg | egrep -v "(^\[|^$|^#)"`"
        done
}

function is_process_in_mig_ctrl
{
	get_all_group
	for gro in $G_LIST;do
		sed -n "/^\[$gro\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$|^#)" | egrep "^[[:space:]]*$1[[:space:]]*$" &> /dev/null
		if [ $? -eq 0 ];then
			process_group=`echo $gro | sed 's/\_list//g'`
			return 
		fi
	done
	return 1
}

# get process name by group name
function get_processname_by_group
{
	if [ $# -eq 0 ];then
		echo "Usage: $0 group_name"
		return 1
	else
		g_in_mig_ctrl=`sed -n "/^\[GROUP_LIST\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)" | grep "^$1_list$" | grep -v grep`
		if [ "$g_in_mig_ctrl" == "" ];then
			echo "group $1 is not in process.cfg" 
			return 1
		else
			process_name_list=`sed -n "/^\[$1_list\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)"`
		fi
	fi
}

# get process parameter info for one process
function get_single_process_info 
{
	clear_variables
	if [ $# -eq 0 ];then
		echo "Usage: $0 process_name"
		return 1
	else
		is_process_in_mig_ctrl $1
		if [ $? -ne 0 ];then
			echo "process '$1' is not in $CONFIG_FILE"
		else
			process_name=$1
			`ps -ef | grep $1 | grep -v grep | grep -v 'app_st'  &> /dev/null` && process_status="RUNNING" || process_status="STOPPED"
			[ "$process_status" == "RUNNING" ] && process_id=`ps aux | grep $1 | grep -v grep | grep -v 'vi' | grep -v 'app_st' | awk '$2 != '$this_pid'{print $2}' | head -1`
			[ "$process_status" == "RUNNING" ] && process_cpu=`ps aux | grep $1 | grep -v grep | grep -v 'vi' | grep -v 'app_st' | awk '$2 != '$this_pid'{print $3}' | head -1`
			[ "$process_status" == "RUNNING" ] && process_mem=`ps aux | grep $1 | grep -v grep | grep -v 'vi' | grep -v 'app_st' | awk '$2 != '$this_pid'{print $5}' | head -1`
			start_time="2017-10-23 09:23:41"
		fi
	fi
}

function format_print 
{
	line=$1

	[ "$process_name" == "" ] && return

	if [ $1 -eq 0 -o $1 -gt 25 ];then
		cur_line=0
		awk 'BEGIN{printf "%-35s%-20s%-15s%-15s%-15s%-15s%-18s\n", "PROCESS_NAME-----------------------","GROUP--------------","STATUS--------","PID------------","CPU------------","MEMORY---------","START_TIME----------"}'
	fi
	
	awk -v p_name=$process_name -v p_group=$process_group -v p_status=$process_status -v p_pid=$process_id -v p_cpu=$process_cpu -v p_mem=$process_mem -v p_starttime="$start_time" 'BEGIN{printf "%-35s%-20s%-15s%-15s%-15s%-15s%-18s\n",p_name,p_group,p_status,p_pid,p_cpu,p_mem,p_starttime}'

}


cur_line=0
if [ $# -gt 0 ];then
	if [ "$1" == "-g" ];then
		shift
		gname_list=$@
		for gn in $gname_list;do
			get_processname_by_group $gn
			for pn in $process_name_list;do
				get_single_process_info $pn && format_print $cur_line
				cur_line=$[ $cur_line + 1 ]
			done
		done
	else
		for p in "$@"
		do
			get_single_process_info $p && format_print $cur_line
			cur_line=$[ $cur_line + 1 ]		
		done
	fi
else
	get_all_process
	for pro in $all_pro;do
		get_single_process_info $pro && format_print $cur_line
		cur_line=$[ $cur_line + 1 ]
	done
fi


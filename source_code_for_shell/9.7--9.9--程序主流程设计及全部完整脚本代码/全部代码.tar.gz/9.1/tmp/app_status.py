#!/usr/bin/python
# -*- coding:UTF-8 -*-
# Func: Get Process Satus in mig_ctrl.ini

import re
import os
import sys
import os.path
import time
import psutil

# Define Variables
CONFIG_FILE='/root/bash-scripts/sh/app_test/mig_ctrl.ini'

# Dispaly Help Information
def print_usage():
    help_info = '''
1)  ./app_status.py { -a | all | ALL }				# Display all process status
2)  ./app_status.py  -g  group_name1,[group_name1],[...]	# Display process status in the group by group name
3)  ./app_status.py process_name1,[process_name2],[...]		# Display process status by process name '''
    print help_info+'\n'
    sys.exit()

# Return Values: dict
def init_mig_ctrl_dict():
    f1 = open(CONFIG_FILE,'r')
    count = 1
    num_list = []
    content_list = []
    for line in f1:
        num_list.append(count)
        content_list.append(line.replace('\n',''))
	count += 1
    f1.close()
    return dict(zip(num_list,content_list))

def init_group_list():
    d1 = init_mig_ctrl_dict()
   
    d2 = {}
    group_key_no = 0
    group_next_no = 0
    group_list = []
    for k,v in d1.items():
	if re.match('\[GROUP_LIST\]',v):
	    group_key_no = k
	    break
    l1 = []
    for k,v in d1.items():
	if re.match('\[.*\]',v):
	    l1.append(k)
    l1.sort()
    group_next_no = l1[l1.index(group_key_no)+1]

    f1 = open(CONFIG_FILE,'r')
    
    count = 0
    for line in f1:
	if count >= group_next_no:
	    break
	else:
	    if re.match('(\[.*\]|^#)',line) or line.strip() == '':
	        pass
 	    else:
	        group_list.append(line.replace('\n',''))
	count += 1
    f1.close()
    return group_list

def get_processlist_by_group(g_name):
    f1 = open(CONFIG_FILE,'r')

    process_list = []
    flag = 0
    for line in f1:
	if line == '[' + g_name + ']\n':
	    flag = 1
	    continue
	if flag == 1 and line.strip() != '': 
	    if re.match('\[.*\]',line):
		break
	    else:
		if line.startswith('#'):
		    continue
		else:
	    	    process_list.append(line.replace('\n','').strip())
        else:
	    continue
    return process_list

def is_process_in_configfile(process_name):

    f1 = open(CONFIG_FILE,'r')
    return process_name in ( result for result in ( line.replace('\n','').strip() for line in f1) )

def get_groupname_by_process(process_name):
    
    g_list = init_group_list()
    for g_name in g_list:
        p_list = get_processlist_by_group(g_name)
	if process_name.strip() in p_list:
	    return g_name.replace('_list','').strip()
	    break
	else:
	    continue
    return ''

def get_process_info(process_name):

    this_pid = os.getpid()
    p_file = psutil.os.popen("ps -ef | grep %s | grep -v grep | awk '$2 != %d{print $2}'" % (process_name,this_pid))
    
    pid = 0
    for line in p_file:
	if line != '':
	    pid = int(line)

    if pid != 0:
    	p_obj = psutil.Process(pid)
    	process_pid = pid
    	process_cpu = p_obj.cpu_percent()
    	process_mem = p_obj.memory_info().vms / 1024
    	if p_obj.is_running():
	    process_status = 'RUNNING'
    	else:
	    process_status = 'STOPPED'
    	process_create_time = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(p_obj.create_time()))
    else:
	process_pid = 'NULL'
	process_cpu = 'NULL'
	process_mem = 'NULL'
	process_status = 'STOPPED'
	process_create_time = 'NULL'

    return process_status,process_pid,process_cpu,process_mem,process_create_time

p_list = []

if len(sys.argv) == 1 or (len(sys.argv)==2 and sys.argv[1] in ("-a","all","ALL")):
    g_list = init_group_list()
    for g_name in g_list:
	p_tmp_list = get_processlist_by_group(g_name)
	for p_name in p_tmp_list:
	    p_list.append(p_name)
elif len(sys.argv) >= 2 and sys.argv[1] in ("-h","--help"):
    print_usage() 
else: 
    if sys.argv[1] == "-g":
        for g_name in sys.argv[2:]:
	    print g_name
	    p_tmp_list = get_processlist_by_group(g_name+'_list')
	    for p_name in p_tmp_list:
	        p_list.append(p_name)

    else:
	for p_name in sys.argv[1:]:
	    p_list.append(p_name)
	
print "now time is %s" % time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())

print "%-40s%-20s%-20s%-10s%-8s%-8s%-20s" % ('PROCESS_NAME----------------------------','GROUP_NAME----------','STATUS--------------','PID-------','CPU-----','MEMORY----','CREATE_TIME-------')

if p_list:
    for p_name in p_list:
	if not is_process_in_configfile(p_name.strip()):
	    print "%s is not found in mig_ctrl.ini" % p_name
	else:
	    p_sts,p_pid,p_cpu,p_mem,p_ctime= get_process_info(p_name)
	    gro_name = get_groupname_by_process(p_name)
	    print "%-40s%-20s%-20s%-10s%-8s%-10s%-20s" % (p_name,gro_name,p_sts,p_pid,p_cpu,p_mem,p_ctime)

print "now time is %s" % time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())

#!/bin/bash
#
# Func: start process in mig_ctrl.ini

# Define Variables
HOME_DIR=/root/lesson/9.1/			# home directory
CONFIG_FILE=process.cfg				# config file name
G_LIST=""                                       # all groups in mig_ctrl.ini
this_pid=$$

# Information for help
function usage
{
        cat << EOF
Usage 1: ./app_start PROCES_NAME                # Start Process By Process Name 
Usage 2: ./app_start.sh -a                      # Satrt All Process In ig_ctrl.ini      
Usage 3: ./app_start.sh all                     # Satrt All Process In ig_ctrl.ini 
Usage 4: ./app_start.sh ALL                     # Satrt All Process In ig_ctrl.ini
Usage 5：./app_start.sh -g GROUP_NAME           # Satrt Proecss By Group Name
EOF
}

# get all groups in mig_ctrl.ini
function get_all_group 
{
        if [ ! -e $HOME_DIR/$CONFIG_FILE ];then
                echo "$CONFIG_FILE is not exist..please check.." 
                return 1
		exit
        else
                G_LIST=`sed -n "/^\[GROUP_LIST\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)"`
                if [ "$G_LIST" == "" ];then
                        echo "no group in $CONFIG_FILE"
                        return 1
                fi
        fi
}

# Get process by group name
function get_processname_by_group
{
        if [ $# -eq 0 ];then
                echo "Usage: $0 group_name"
                return 1
        else
                g_in_mig_ctrl=`sed -n "/^\[GROUP_LIST\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)" | grep "^$1_list$" | grep -v grep`
                if [ "$g_in_mig_ctrl" == "" ];then
                        echo "group $1 is not in mig_ctrl.ini" 
                        return 1
                else
                        process_name_list=`sed -n "/^\[$1_list\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)"`
			return
                fi
        fi
}

# Get all process in mig_ctrl.ini
function get_all_process
{
        all_pro=        # init variables
        get_all_group
        for g in $G_LIST;do
                all_pro="${all_pro} `sed -n "/^\[$g\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$|^#)"`"
        done
}

# whether process is in mig_ctrl.ini { True | False }
function is_process_in_mig_ctrl
{
        get_all_group
        for gro in $G_LIST;do
                sed -n "/^\[$gro\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$|^#)" | grep "^[[:space:]]*$1[[:space:]]*$" &> /dev/null
                if [ $? -eq 0 ];then
                        return
                fi
        done
        return 1
}

function get_process_para {
	
	# Get Process Para Info From mig_ctrl.ini
	p_desc=`sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^desc | awk -F'=' '{print $2}'`	
	p_program_name=`sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^program_name | awk -F'=' '{print $2}'`
	p_main_para=`sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^main_para | awk -F'=' '{print $2}'`
	p_para="$(sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^parameter | awk -F'=' '{print $2}')"

}
 
function start_process
{
	is_process_in_mig_ctrl $1 
	if [ $? -eq 1 ];then
		echo "process: $1 is not in mig_ctrl.ini"
		return
	fi
	
	`ps -ef | grep $1 | grep -v "$this_pid" | grep -v grep > /dev/null 2>&1`
	if [ $? -eq 0 ];then
		echo "process: $1 is already runing,can't start again"
		return
	fi

	get_process_para $1
	[[ "$p_program_name" == "" || "$p_para" == "" ]] && echo ">>>>>>command or parameter not found<<<<<<" && return
	
	file_name=`echo $p_para | awk '{print $2}'`
	if [ -e $file_name ];then
		$p_program_name $p_para &> /dev/null & 
		echo "nohup $p_program_name $p_para &"
	else
		echo "$file_name not found"
		return
	fi	
}

function monitor_process
{
	[ "$name_list" == "" ] && return
	
#	awk 'BEGIN{printf "%-35s%-20s%-15s%-15s%-15s%-15s%-18s\n", "PROCESS_NAME-----------------------","GROUP--------------","STATUS--------","PID------------","CPU------------","MEMORY---------","START_TIME----------"}'

#	for p in $name_list;do
		$HOME_DIR/app_status.sh $name_list
#	done | grep -v "^PROCESS_NAME" | grep -v "not in mig_ctrl.ini"
}

if [ $# -eq 0 ];then
	usage
	exit 1
fi 

if [ "$1" == "-h" ] || [ "$1" == "--help" ];then
        usage
        exit 1
fi

while [ $# -gt 0 ]
do
	case $1 in
		-g)
			shift
			[ "$group_list" == "" ] && group_list=$@
			by_group=1
			break
			;;
		(-a|all|ALL)
			get_all_process
			[ "$name_list" == "" ] && name_list=$all_pro			
			shift
			;;
		*)
			[ "$name_list" == "" ] && name_list=$1 || name_list="$name_list $1"
			by_process=1
			shift
			;;
	esac
done

# Get All Process Name By Group Name
for gn in $group_list;do
	get_processname_by_group $gn
	if [ $? -eq 0 ];then
		for p_name in $process_name_list;do 
			[ "$name_list" == "" ] && name_list=$p_name || name_list="$name_list $p_name"
		done
	fi
done

for pn in $name_list;do
	start_process $pn
done
	
sleep 1
monitor_process $name_list

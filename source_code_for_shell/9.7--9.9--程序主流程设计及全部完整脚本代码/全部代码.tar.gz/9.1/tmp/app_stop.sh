#!/bin/bash
#
# Func: start process in process.cfg

# Information for help
function usage
{
        cat << EOF
Usage 1: ./app_stop.sh PROCES_NAME             # Start Process By Process Name 
Usage 2: ./app_stop.sh -a                      # Satrt All Process In process.cfg 
Usage 3: ./app_stop.sh all                     # Satrt All Process In process.cfg
Usage 4: ./app_stop.sh ALL                     # Satrt All Process In process.cfg
Usage 5：./app_stop.sh -g GROUP_NAME           # Satrt Proecss By Group Name
EOF
}

# Define Variables
HOME_DIR=/root/lesson/9.1/			# home directory
CONFIG_FILE=process.cfg                       	# config file name
G_LIST=""                                       # all groups in process.cfg
this_pid=$$

# get all groups in process.cfg
function get_all_group 
{
        if [ ! -e $HOME_DIR/$CONFIG_FILE ];then
                echo "$CONFIG_FILE is not exist..please check.." 
                return 1
		exit
        else
                G_LIST=`sed -n "/^\[GROUP_LIST\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)"`
                if [ "$G_LIST" == "" ];then
                        echo "no group in $CONFIG_FILE"
                        return 1
                fi
        fi
}

# Get process by group name
function get_processname_by_group
{
        if [ $# -eq 0 ];then
                echo "Usage: $0 group_name"
                return 1
        else
                g_in_mig_ctrl=`sed -n "/^\[GROUP_LIST\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)" | grep "^$1_list$" | grep -v grep`
                if [ "$g_in_mig_ctrl" == "" ];then
                        echo "group $1 is not in process.cfg" 
                        return 1
                else
                        process_name_list=`sed -n "/^\[$1_list\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[.*\]$|^$|^#)"`
                        return
                fi
        fi
}

# Get all process in process.cfg
function get_all_process
{
        all_pro=        # init variables
        get_all_group
        for g in $G_LIST;do
                all_pro="${all_pro} `sed -n "/^\[$g\]$/,/^\[.*\]$/p" process.cfg | egrep -v "(^\[|^$|^#)"`"
        done
}

# whether process is in process.cfg { True | False }
function is_process_in_mig_ctrl
{
        get_all_group
        for gro in $G_LIST;do
                sed -n "/^\[$gro\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$|^#)" | grep "^[[:space:]]*$1[[:space:]]*$" &> /dev/null
                if [ $? -eq 0 ];then
                        return
                fi
        done
        return 1
}

function get_process_para {
	
	# Get Process Para Info From process.cfg
	p_desc=`sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^desc | awk -F'=' '{print $2}'`	
	p_program_name=`sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^program_name | awk -F'=' '{print $2}'`
	p_main_para=`sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^main_para | awk -F'=' '{print $2}'`
	p_para="$(sed -n "/^\[$1\]$/,/^\[.*\]$/p" $HOME_DIR/$CONFIG_FILE | egrep -v "(^\[|^$)" | grep ^parameter | awk -F'=' '{print $2}')"

}
 
function get_process_pid
{
	process_id=`ps aux | grep $1 | grep -v grep | grep -v "app_st" | awk '$2 != "$this_pid"{print $2}'`
	if [ "$process_id" != "" ];then
		return
	else
		return 1
	fi
}

function stop_process
{
        is_process_in_mig_ctrl $1
        if [ $? -eq 1 ];then
                echo "process: $1 is not in process.cfg"
                return
        fi

        get_process_pid $1
        if [ $? -eq 0 ];then
                kill $process_id
                echo "Stop Process $1....kill $process_id &"
        else
                echo "process: $1 is already stopped,can't stop again"
                return
        fi
}

function monitor_process
{
	[ "$name_list" == "" ] && return

	#awk 'BEGIN{printf "%-35s%-20s%-15s%-15s%-15s%-15s%-18s\n", "PROCESS_NAME-----------------------","GROUP--------------","STATUS--------","PID------------","CPU------------","MEMORY---------","START_TIME----------"}'

#	for p in $name_list;do
		$HOME_DIR/app_status.sh $name_list 
#	done | grep -v "^PROCESS_NAME" | grep -v "is not in process.cfg"
}

if [ $# -eq 0 ];then
        usage
	exit 1
fi

if [ "$1" == "-h" ] || [ "$1" == "--help" ];then
	usage
	exit 1
fi

while [ $# -gt 0 ]
do
	case $1 in
		-g)
			shift
			[ "$group_list" == "" ] && group_list=$@
			by_group=1
			break
			;;
		(-a|all|ALL)
			get_all_process
			[ "$name_list" == "" ] && name_list=$all_pro
			shift
			;;
		*)
			[ "$name_list" == "" ] && name_list=$1 || name_list="$name_list $1"
			by_process=1
			shift
			;;
	esac
done

# Get All Process Name By Group Name
for gn in $group_list;do
        get_processname_by_group $gn
        if [ $? -eq 0 ];then
                for p_name in $process_name_list;do
                        [ "$name_list" == "" ] && name_list=$p_name || name_list="$name_list $p_name"
                done
        fi
done
	
for pn in $name_list;do
	stop_process $pn
done
	
sleep 1
monitor_process $name_list
